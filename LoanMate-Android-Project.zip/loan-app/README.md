# LoanMate — Small Loan Manager

A mobile-friendly personal loan record manager. It tracks borrowers, loans, monthly interest, payments and pending balances. It does **not** hold or transfer money.

## Demo calculation
For a ₹5,000 loan at 10% monthly simple interest for 1 month:
- Principal: ₹5,000
- Interest: ₹500
- Total due: ₹5,500

## Run on a computer
1. Install Node.js 18+.
2. Open a terminal in this folder.
3. Run `npm install`.
4. Run `npm start`.
5. Open `http://localhost:3000`.

## Deploy
This project needs a Node.js host with persistent storage because `data/loans.json` is written by the server. Use a service that supports a Node web service and persistent disk/volume if you want the data to survive redeploys. For a free demo, you can run it locally; for production, use a managed database instead of JSON storage.

## Database structure
Current demo storage is `data/loans.json` with three collections:

### borrowers
- id: string
- name: string
- phone: string
- notes: string

### loans
- id: string
- borrowerId: string -> borrowers.id
- amount: number
- rate: number (monthly percent)
- dueDate: YYYY-MM-DD
- createdAt: YYYY-MM-DD

### payments
- id: string
- loanId: string -> loans.id
- amount: number
- date: YYYY-MM-DD
- note: string

## Production database recommendation
Move these collections to PostgreSQL/Supabase or another managed database before real-world multi-user use. Add authentication, role-based access, encrypted sensitive fields, audit logs, backups, and server-side validation.

## Important legal/product note
This is a record-keeping app, not a regulated lending/payment platform. Before using it to offer loans commercially, get local legal advice on applicable money-lending, interest-rate, KYC, recovery, consumer-protection, tax and data-protection requirements.
