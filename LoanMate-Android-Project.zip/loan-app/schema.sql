-- Production-oriented relational schema. Demo currently uses data/loans.json.
CREATE TABLE borrowers (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  phone TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE loans (
  id TEXT PRIMARY KEY,
  borrower_id TEXT NOT NULL REFERENCES borrowers(id),
  principal NUMERIC(12,2) NOT NULL CHECK (principal > 0),
  monthly_rate NUMERIC(7,4) NOT NULL CHECK (monthly_rate >= 0),
  due_date DATE NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE payments (
  id TEXT PRIMARY KEY,
  loan_id TEXT NOT NULL REFERENCES loans(id),
  amount NUMERIC(12,2) NOT NULL CHECK (amount > 0),
  payment_date DATE NOT NULL,
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX loans_borrower_idx ON loans(borrower_id);
CREATE INDEX payments_loan_idx ON payments(loan_id);
